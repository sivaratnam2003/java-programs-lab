import java.lang.*;
class Comm2{
public static void main(String args[]){
int a = Integer.parseInt(args[0]);
int b = Integer.parseInt(args[1]);
int c = a+b;
System.out.println("Sum"+c);
}
}